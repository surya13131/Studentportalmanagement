package studentportalmanagement.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import studentportalmanagement.DTO.MarkDTO;
import studentportalmanagement.Entity.MarkEntity;
import studentportalmanagement.Service.MarkService;

import java.util.List;

@RestController
@RequestMapping("/api/marks")
@CrossOrigin
public class MarkController {

    @Autowired
    private MarkService markService;

    @PostMapping("/Addmark")
    public MarkDTO addMark(@RequestBody MarkDTO markDTO) {
        MarkEntity saved = markService.AddmarkLogic(markDTO);

        // Convert Entity back to DTO to send clean response
        MarkDTO response = new MarkDTO();
        response.setReg(saved.getStudent().getReg());  // include reg
        response.setStudentName(saved.getStudentName());
        response.setSubject1(saved.getSubject1());
        response.setSubject2(saved.getSubject2());
        response.setSubject3(saved.getSubject3());
        response.setTotal(saved.getTotal());
        response.setResult(saved.getResult());
        response.setGrade1(saved.getGrade1());
        response.setGrade2(saved.getGrade2());
        response.setGrade3(saved.getGrade3());
        response.setSubject1Result(saved.getSubject1Result());
        response.setSubject2Result(saved.getSubject2Result());
        response.setSubject3Result(saved.getSubject3Result());

        return response;
    }

    @GetMapping("/Display/{reg}")
    public List<MarkDTO> displayMark(@PathVariable Long reg) {
        return markService.Displaymarklogic(reg);
    }

}
