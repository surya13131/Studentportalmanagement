package studentportalmanagement.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import studentportalmanagement.DTO.StudentDTO;
import studentportalmanagement.Entity.StudentEntity;
import studentportalmanagement.Service.StudentService;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@CrossOrigin
public class StudentController {

    @Autowired
    private StudentService studentService;

    // ✅ Get all students
    @GetMapping
    public ResponseEntity<?> getAllStudents() {
        try {
            List<StudentEntity> students = studentService.getAllStudents();

            // Map entity to DTO to avoid exposing password
            List<StudentDTO> studentDTOs = students.stream()
                    .map(s -> new StudentDTO(
                            s.getReg(),
                            s.getName(),
                            null, // hide password for security
                            s.getYear(),
                            s.getClg()
                    ))
                    .toList();

            return ResponseEntity.ok(studentDTOs);
        } catch (Exception e) {
            e.printStackTrace(); // Log error
            return ResponseEntity.status(500).body("Failed to fetch students: " + e.getMessage());
        }
    }

    // ✅ Add a new student
    @PostMapping
    public ResponseEntity<?> addStudent(@RequestBody StudentEntity student) {
        try {
            System.out.println("Adding Student: " + student.getReg() + ", " + student.getName());
            StudentEntity saved = studentService.addStudent(student);
            // return DTO instead of raw entity
            StudentDTO dto = new StudentDTO(
                    saved.getReg(),
                    saved.getName(),
                    null, // do not return password
                    saved.getYear(),
                    saved.getClg()
            );
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Failed to save student: " + e.getMessage());
        }
    }

    // ✅ Update student by ID
    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(@PathVariable Long id, @RequestBody StudentEntity student) {
        try {
            StudentEntity updated = studentService.updateStudent(id, student);
            if (updated != null) {
                StudentDTO dto = new StudentDTO(
                        updated.getReg(),
                        updated.getName(),
                        null,
                        updated.getYear(),
                        updated.getClg()
                );
                return ResponseEntity.ok(dto);
            } else {
                return ResponseEntity.status(404).body("Student with ID " + id + " not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Failed to update student: " + e.getMessage());
        }
    }

    // ✅ Delete student by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable Long id) {
        try {
            studentService.deleteStudent(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Failed to delete student: " + e.getMessage());
        }
    }

    // ✅ Login using reg and password
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody StudentDTO studentDTO) {
        try {
            System.out.println("Login attempt for reg: " + studentDTO.getReg());
            boolean success = studentService.Loginlogic(studentDTO.getReg(), studentDTO.getPassword());

            if (success) {
                return ResponseEntity.ok("Login successful");
            } else {
                return ResponseEntity.status(401).body("Invalid registration number or password");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Login error: " + e.getMessage());
        }
    }
}
