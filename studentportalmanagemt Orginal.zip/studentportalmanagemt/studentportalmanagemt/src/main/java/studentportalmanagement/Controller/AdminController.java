package studentportalmanagement.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import studentportalmanagement.Service.AdminService;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin
public class AdminController {

    @Autowired
    private AdminService adminService;

    // ✅ login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        boolean success = adminService.login(request.getUsername(), request.getPassword());
        if (success) {
            return ResponseEntity.ok("success");
        } else {
            return ResponseEntity.status(401).body("fail");
        }
    }

    // ✅ change password
    @PutMapping("/changepassword/{username}")
    public ResponseEntity<?> changePassword(@PathVariable String username, @RequestBody ChangePasswordRequest request) {
        boolean changed = adminService.changePassword(username, request.getOldPassword(), request.getNewPassword());
        if (changed) {
            return ResponseEntity.ok("success");
        } else {
            return ResponseEntity.status(400).body("fail");
        }
    }

    // ✅ add new admin with current admin credentials
    @PostMapping("/register")
    public ResponseEntity<?> addAdmin(@RequestBody AddAdminRequest request) {
        boolean added = adminService.verifyAndAddAdmin(
                request.getCurrentAdminUsername(),
                request.getCurrentAdminPassword(),
                request.getNewAdminUsername(),
                request.getNewAdminPassword()
        );
        if (added) {
            return ResponseEntity.ok("success");
        } else {
            return ResponseEntity.status(403).body("Permission denied or wrong current password");
        }
    }

    // DTOs
    public static class LoginRequest {
        private String username;
        private String password;
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    public static class ChangePasswordRequest {
        private String oldPassword;
        private String newPassword;
        public String getOldPassword() { return oldPassword; }
        public void setOldPassword(String oldPassword) { this.oldPassword = oldPassword; }
        public String getNewPassword() { return newPassword; }
        public void setNewPassword(String newPassword) { this.newPassword = newPassword; }
    }

    public static class AddAdminRequest {
        private String currentAdminUsername;
        private String currentAdminPassword;
        private String newAdminUsername;
        private String newAdminPassword;

        public String getCurrentAdminUsername() { return currentAdminUsername; }
        public void setCurrentAdminUsername(String currentAdminUsername) { this.currentAdminUsername = currentAdminUsername; }

        public String getCurrentAdminPassword() { return currentAdminPassword; }
        public void setCurrentAdminPassword(String currentAdminPassword) { this.currentAdminPassword = currentAdminPassword; }

        public String getNewAdminUsername() { return newAdminUsername; }
        public void setNewAdminUsername(String newAdminUsername) { this.newAdminUsername = newAdminUsername; }

        public String getNewAdminPassword() { return newAdminPassword; }
        public void setNewAdminPassword(String newAdminPassword) { this.newAdminPassword = newAdminPassword; }
    }
}
