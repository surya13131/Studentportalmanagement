package studentportalmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class StudentPortalManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentPortalManagementApplication.class, args);
	}
}
