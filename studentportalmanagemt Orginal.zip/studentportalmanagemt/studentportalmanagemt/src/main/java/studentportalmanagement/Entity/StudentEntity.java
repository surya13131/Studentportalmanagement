package studentportalmanagement.Entity;

import jakarta.persistence.*;

@Entity
@Table(
        name = "student_entity",
        indexes = {
                @Index(name = "idx_reg", columnList = "reg")
        }
)
public class StudentEntity {

    @Id
    @Column(name = "reg", nullable = false, unique = true)
    private Long reg;

    private String name;

    private String password;

    private int year;

    private String clg;

    // Getters and Setters

    public Long getReg() {
        return reg;
    }

    public void setReg(Long reg) {
        this.reg = reg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getClg() {
        return clg;
    }

    public void setClg(String clg) {
        this.clg = clg;
    }
}
