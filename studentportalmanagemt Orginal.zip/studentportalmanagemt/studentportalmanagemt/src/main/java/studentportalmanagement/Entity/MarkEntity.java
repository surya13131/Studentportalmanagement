package studentportalmanagement.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "mark_entity")
public class MarkEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String studentName;

    private int subject1;
    private int subject2;
    private int subject3;

    private int total;
    private String result;

    private String grade1;
    private String grade2;
    private String grade3;

    private String subject1Result;
    private String subject2Result;
    private String subject3Result;

    // FK link to student
    @ManyToOne
    @JoinColumn(name = "student_reg", referencedColumnName = "reg")
    private StudentEntity student;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public int getSubject1() { return subject1; }
    public void setSubject1(int subject1) { this.subject1 = subject1; }

    public int getSubject2() { return subject2; }
    public void setSubject2(int subject2) { this.subject2 = subject2; }

    public int getSubject3() { return subject3; }
    public void setSubject3(int subject3) { this.subject3 = subject3; }

    public int getTotal() { return total; }
    public void setTotal(int total) { this.total = total; }

    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }

    public String getGrade1() { return grade1; }
    public void setGrade1(String grade1) { this.grade1 = grade1; }

    public String getGrade2() { return grade2; }
    public void setGrade2(String grade2) { this.grade2 = grade2; }

    public String getGrade3() { return grade3; }
    public void setGrade3(String grade3) { this.grade3 = grade3; }

    public String getSubject1Result() { return subject1Result; }
    public void setSubject1Result(String subject1Result) { this.subject1Result = subject1Result; }

    public String getSubject2Result() { return subject2Result; }
    public void setSubject2Result(String subject2Result) { this.subject2Result = subject2Result; }

    public String getSubject3Result() { return subject3Result; }
    public void setSubject3Result(String subject3Result) { this.subject3Result = subject3Result; }

    public StudentEntity getStudent() {
        return student;
    }
    public void setStudent(StudentEntity student) {
        this.student = student;
    }
}
