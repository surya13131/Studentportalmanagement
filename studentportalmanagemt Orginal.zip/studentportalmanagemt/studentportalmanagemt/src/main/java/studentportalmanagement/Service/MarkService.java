package studentportalmanagement.Service;

import studentportalmanagement.DTO.MarkDTO;
import studentportalmanagement.Entity.MarkEntity;
import java.util.List;

public interface MarkService {
    MarkEntity AddmarkLogic(MarkDTO markDTO);
    List<MarkDTO> Displaymarklogic(Long reg);
}
