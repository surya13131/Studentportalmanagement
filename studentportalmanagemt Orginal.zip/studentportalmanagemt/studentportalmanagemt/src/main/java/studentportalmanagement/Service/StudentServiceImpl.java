package studentportalmanagement.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import studentportalmanagement.Entity.StudentEntity;
import studentportalmanagement.Repository.StudentRepository;

import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // ✅ Get all students
    @Override
    public List<StudentEntity> getAllStudents() {
        return studentRepository.findAll();
    }

    // ✅ Add a new student
    @Override
    public StudentEntity addStudent(StudentEntity student) {
        return studentRepository.save(student);
    }

    // ✅ Update student by ID
    @Override
    public StudentEntity updateStudent(Long id, StudentEntity updated) {
        Optional<StudentEntity> optionalStudent = studentRepository.findById(id);

        if (optionalStudent.isPresent()) {
            StudentEntity student = optionalStudent.get();
            student.setName(updated.getName());
            student.setPassword(updated.getPassword());
            student.setYear(updated.getYear());
            student.setClg(updated.getClg());
            // We usually don't update 'reg' (primary key), so skip it.
            return studentRepository.save(student);
        }

        return null; // Student not found
    }

    // ✅ Delete student by ID
    @Override
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    // ✅ Login logic using reg and password
    @Override
    public boolean Loginlogic(Long reg, String password) {
        Optional<StudentEntity> studentOpt = studentRepository.findById((long) reg);

        if (studentOpt.isPresent()) {
            StudentEntity student = studentOpt.get();
            return student.getPassword().equals(password);
        }

        return false;
    }
}
