package studentportalmanagement.Service;

public interface AdminService {
    boolean login(String username, String password);

    boolean changePassword(String username, String oldPassword, String newPassword);

    // keep the old style if you want (optional)
    boolean addAdmin(String username, String password);

    // ✅ added method to verify current admin before adding new one
    boolean verifyAndAddAdmin(String currentAdminUsername, String currentAdminPassword, String newAdminUsername, String newAdminPassword);
}
