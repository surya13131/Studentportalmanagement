package studentportalmanagement.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import studentportalmanagement.Entity.AdminEntity;
import studentportalmanagement.Repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public boolean login(String username, String password) {
        System.out.println("DEBUG: login attempt for username=" + username);
        boolean found = adminRepository.findByUsernameAndPassword(username, password).isPresent();
        if (found) {
            System.out.println("DEBUG: login successful for username=" + username);
        } else {
            System.out.println("DEBUG: login failed for username=" + username);
        }
        return found;
    }

    @Override
    public boolean changePassword(String username, String oldPassword, String newPassword) {
        System.out.println("DEBUG: changePassword for username=" + username + ", oldPassword=" + oldPassword);
        var adminOpt = adminRepository.findByUsernameAndPassword(username, oldPassword);
        if (adminOpt.isPresent()) {
            AdminEntity admin = adminOpt.get();
            admin.setPassword(newPassword);
            adminRepository.save(admin);
            System.out.println("DEBUG: password changed successfully for " + username);
            return true;
        } else {
            System.out.println("ERROR: password change failed - old password incorrect for " + username);
            return false;
        }
    }

    @Override
    public boolean addAdmin(String username, String password) {
        System.out.println("DEBUG: addAdmin called with username=" + username);
        if (adminRepository.findByUsername(username).isPresent()) {
            System.out.println("ERROR: addAdmin failed - username already exists: " + username);
            return false;
        }
        AdminEntity admin = new AdminEntity();
        admin.setUsername(username);
        admin.setPassword(password);
        adminRepository.save(admin);
        System.out.println("DEBUG: new admin added: " + username);
        return true;
    }

    @Override
    public boolean verifyAndAddAdmin(String currentUsername, String currentPassword, String newUsername, String newPassword) {
        System.out.println("DEBUG: verifyAndAddAdmin called by currentUsername=" + currentUsername + " for newUsername=" + newUsername);
        var adminOpt = adminRepository.findByUsernameAndPassword(currentUsername, currentPassword);
        if (adminOpt.isPresent()) {
            if (adminRepository.findByUsername(newUsername).isPresent()) {
                System.out.println("ERROR: verifyAndAddAdmin failed - new admin username already exists: " + newUsername);
                return false;
            }
            AdminEntity newAdmin = new AdminEntity();
            newAdmin.setUsername(newUsername);
            newAdmin.setPassword(newPassword);
            adminRepository.save(newAdmin);
            System.out.println("DEBUG: verifyAndAddAdmin succeeded - new admin added: " + newUsername);
            return true;
        } else {
            System.out.println("ERROR: verifyAndAddAdmin failed - current admin credentials wrong: " + currentUsername);
            return false;
        }
    }
}
