package studentportalmanagement.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import studentportalmanagement.DTO.MarkDTO;
import studentportalmanagement.Entity.MarkEntity;
import studentportalmanagement.Entity.StudentEntity;
import studentportalmanagement.Repository.MarkRepository;
import studentportalmanagement.Repository.StudentRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class MarkServiceImpl implements MarkService {

    @Autowired
    private MarkRepository markRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public MarkEntity AddmarkLogic(MarkDTO dto) {

        // 1️⃣ find the student
        StudentEntity student = studentRepository.findByReg(dto.getReg())
                .orElseThrow(() -> new RuntimeException("Student not found with reg: " + dto.getReg()));

        MarkEntity mark = new MarkEntity();
        mark.setStudent(student);
        mark.setStudentName(student.getName());

        // 2️⃣ subject marks
        int s1 = dto.getSubject1();
        int s2 = dto.getSubject2();
        int s3 = dto.getSubject3();

        mark.setSubject1(s1);
        mark.setSubject2(s2);
        mark.setSubject3(s3);

        int total = s1 + s2 + s3;
        mark.setTotal(total);

        // 3️⃣ overall result remains Pass/Fail
        String result = (s1 >= 35 && s2 >= 35 && s3 >= 35) ? "Pass" : "Fail";
        mark.setResult(result);

        // 4️⃣ grades (use "RA" if marks < 35)
        mark.setGrade1(getGrade(s1));
        mark.setGrade2(getGrade(s2));
        mark.setGrade3(getGrade(s3));

        // 5️⃣ subject results remain Pass/Fail
        mark.setSubject1Result(s1 >= 35 ? "Pass" : "Fail");
        mark.setSubject2Result(s2 >= 35 ? "Pass" : "Fail");
        mark.setSubject3Result(s3 >= 35 ? "Pass" : "Fail");

        return markRepository.save(mark);
    }

    // ✅ Grade shows "RA" for marks < 35
    private String getGrade(int marks) {
        if (marks >= 90) return "S";
        else if (marks >= 80) return "A";
        else if (marks >= 70) return "B";
        else if (marks >= 60) return "C";
        else if (marks >= 50) return "D";
        else if (marks >= 40) return "E";
        else if (marks < 35) return "RA"; // 🔁 Less than 35 is RA
        else return "F"; // optional fallback
    }

    @Override
    public List<MarkDTO> Displaymarklogic(Long reg) {
        List<MarkEntity> markEntities = markRepository.findByStudent_Reg(reg);
        List<MarkDTO> dtoList = new ArrayList<>();

        for (MarkEntity entity : markEntities) {
            MarkDTO dto = new MarkDTO();
            dto.setReg(entity.getStudent().getReg());
            dto.setStudentName(entity.getStudent().getName());

            dto.setSubject1(entity.getSubject1());
            dto.setSubject2(entity.getSubject2());
            dto.setSubject3(entity.getSubject3());
            dto.setTotal(entity.getTotal());
            dto.setResult(entity.getResult());
            dto.setGrade1(entity.getGrade1());
            dto.setGrade2(entity.getGrade2());
            dto.setGrade3(entity.getGrade3());
            dto.setSubject1Result(entity.getSubject1Result());
            dto.setSubject2Result(entity.getSubject2Result());
            dto.setSubject3Result(entity.getSubject3Result());

            dtoList.add(dto);
        }

        return dtoList;
    }
}
