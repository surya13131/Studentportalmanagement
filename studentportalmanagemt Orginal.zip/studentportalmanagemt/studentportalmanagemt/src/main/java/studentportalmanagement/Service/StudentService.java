package studentportalmanagement.Service;

import studentportalmanagement.Entity.StudentEntity;

import java.util.List;

public interface StudentService {

    // ✅ Fetch all students
    List<StudentEntity> getAllStudents();

    // ✅ Add a new student
    StudentEntity addStudent(StudentEntity student);

    // ✅ Update existing student by ID
    StudentEntity updateStudent(Long id, StudentEntity student);

    // ✅ Delete a student by ID
    void deleteStudent(Long id);

    // ✅ Login logic using reg and password
    boolean Loginlogic(Long reg, String password);
}
