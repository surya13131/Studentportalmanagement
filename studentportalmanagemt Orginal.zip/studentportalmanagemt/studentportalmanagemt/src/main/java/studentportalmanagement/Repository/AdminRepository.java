package studentportalmanagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import studentportalmanagement.Entity.AdminEntity;

import java.util.Optional;

/**
 * Repository interface for AdminEntity
 * provides CRUD operations and
 * custom finder methods.
 */
public interface AdminRepository extends JpaRepository<AdminEntity, Long> {

    /**
     * Find admin by username and password
     *
     * @param username the admin username
     * @param password the admin password
     * @return Optional of AdminEntity
     */
    Optional<AdminEntity> findByUsernameAndPassword(String username, String password);

    /**
     * Find admin by username
     *
     * @param username the admin username
     * @return Optional of AdminEntity
     */
    Optional<AdminEntity> findByUsername(String username);
}
