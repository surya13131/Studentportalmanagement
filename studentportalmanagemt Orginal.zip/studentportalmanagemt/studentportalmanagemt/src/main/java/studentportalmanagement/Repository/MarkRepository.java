package studentportalmanagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import studentportalmanagement.Entity.MarkEntity;

import java.util.List;

public interface MarkRepository extends JpaRepository<MarkEntity, Long> {

    List<MarkEntity> findByStudent_Reg(Long reg);  // ✅ Correct nested query
}
