package studentportalmanagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import studentportalmanagement.Entity.StudentEntity;

import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<StudentEntity, Long> {

    // Corrected: match the @Id type in StudentEntity
    Optional<StudentEntity> findByReg(Long reg);
}
