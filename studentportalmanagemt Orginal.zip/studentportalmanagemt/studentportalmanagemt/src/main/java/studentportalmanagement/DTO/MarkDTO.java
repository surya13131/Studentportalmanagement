package studentportalmanagement.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MarkDTO {

    private Long reg; // <--- add this for registration number
    private String studentName;
    private Integer subject1;
    private Integer subject2;
    private Integer subject3;

    private Integer total;
    private String result;  // Overall Pass/Fail

    private String grade1;
    private String grade2;
    private String grade3;

    private String subject1Result;
    private String subject2Result;
    private String subject3Result;

    // Getter and Setter for reg
    public Long getReg() {
        return reg;
    }

    public void setReg(Long reg) {
        this.reg = reg;
    }

    // Getters and setters for other fields
    public String getStudentName() {
        return studentName;
    }
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Integer getSubject1() {
        return subject1;
    }
    public void setSubject1(Integer subject1) {
        this.subject1 = subject1;
    }

    public Integer getSubject2() {
        return subject2;
    }
    public void setSubject2(Integer subject2) {
        this.subject2 = subject2;
    }

    public Integer getSubject3() {
        return subject3;
    }
    public void setSubject3(Integer subject3) {
        this.subject3 = subject3;
    }

    public Integer getTotal() {
        return total;
    }
    public void setTotal(Integer total) {
        this.total = total;
    }

    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }

    public String getGrade1() {
        return grade1;
    }
    public void setGrade1(String grade1) {
        this.grade1 = grade1;
    }

    public String getGrade2() {
        return grade2;
    }
    public void setGrade2(String grade2) {
        this.grade2 = grade2;
    }

    public String getGrade3() {
        return grade3;
    }
    public void setGrade3(String grade3) {
        this.grade3 = grade3;
    }

    public String getSubject1Result() {
        return subject1Result;
    }
    public void setSubject1Result(String subject1Result) {
        this.subject1Result = subject1Result;
    }

    public String getSubject2Result() {
        return subject2Result;
    }
    public void setSubject2Result(String subject2Result) {
        this.subject2Result = subject2Result;
    }

    public String getSubject3Result() {
        return subject3Result;
    }
    public void setSubject3Result(String subject3Result) {
        this.subject3Result = subject3Result;
    }
}
