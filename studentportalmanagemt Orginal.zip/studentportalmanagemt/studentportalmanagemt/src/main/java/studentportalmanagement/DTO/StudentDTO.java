package studentportalmanagement.DTO;

public class StudentDTO {

    private Long reg;       // Registration Number
    private String name;    // Student Name
    private String password; // Password
    private int year;       // Year of Study
    private String clg;     // College Name

    // Constructors
    public StudentDTO() {
    }

    public StudentDTO(Long reg, String name, String password, int year, String clg) {
        this.reg = reg;
        this.name = name;
        this.password = password;
        this.year = year;
        this.clg = clg;
    }

    // Getters and Setters
    public Long getReg() {
        return reg;
    }

    public void setReg(Long reg) {
        this.reg = reg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getClg() {
        return clg;
    }

    public void setClg(String clg) {
        this.clg = clg;
    }
}
