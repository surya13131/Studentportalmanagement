package studentportalmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentportalmanagemtApplicationTests {

	@Test
	void contextLoads() {
	}

}
